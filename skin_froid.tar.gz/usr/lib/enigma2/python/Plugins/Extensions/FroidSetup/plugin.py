# -*- coding: utf-8 -*-
# by digiteng...2019
# v3.46, 12.2020
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Tools import Notifications
from Components.config import config
from Components.ConfigList import ConfigListScreen
from enigma import eTimer
import urllib
import urllib2
from Components.Ipkg import IpkgComponent
from Screens.Ipkg import Ipkg
import Screens.Standby 
from Screens.Standby import TryQuitMainloop
import FroidSetup
import configs

try:
	def newipk(result):
		if result:
			us = urllib2.urlopen("https://raw.githubusercontent.com/digiteng/store/master/FroidSkinUpdate/ipk.version") 
			ur = us.read()
			us.close()

			cs = open("/usr/share/enigma2/Froid/skin.version", "r")
			cr = cs.read()
			cs.close()

			url = "https://github.com/digiteng/store/raw/master/FroidSkinUpdate/enigma2-plugin-skins-froid_%s_all.ipk"%(ur)
			ipk_name = "enigma2-plugin-skins-froid_%s_all.ipk" %(ur)
			urllib.urlretrieve(url, "/tmp/%s" % ipk_name)

			cmdList = []
			ipktmp = "/tmp/%s" %(ipk_name)
			cmdList.append((IpkgComponent.CMD_INSTALL, {"package": ipktmp}))
			Notifications.AddNotificationWithCallback(restarte2, Ipkg, cmdList = cmdList)
		else:
			pass

	def restarte2():
		Notifications.AddNotification(Screens.Standby.TryQuitMainloop, 3)

	def upCheck():
		us = urllib2.urlopen("https://raw.githubusercontent.com/digiteng/store/master/FroidSkinUpdate/ipk.version") 
		ur = us.read()
		us.close()

		cs = open("/usr/share/enigma2/Froid/skin.version", "r")
		cr = cs.read()
		cs.close()

		if ur > cr:
			Notifications.AddNotificationWithCallback(newipk, MessageBox, _("NEW VERSION FROID SKIN AVAILABLE !..\n\nDo you want  UPDATE SKIN ?.."), MessageBox.TYPE_YESNO, default=False, timeout=30)

	if config.skin.primary_skin.value == 'Froid/skin.xml': 
		if config.plugins.FroidSetup.autoUp.value == True:
			if config.plugins.FroidSetup.autoUpSel.value == "Start_Boot":
				upCheck()

	if config.skin.primary_skin.value == 'Froid/skin.xml':
		if config.plugins.FroidSetup.autoUp.value==True:
			if config.plugins.FroidSetup.autoUpSel.value == "21600":
				Timer = eTimer()
				Timer.callback.append(upCheck)
				Timer.start(1000*21600, False) #6h=21600sn

	if config.skin.primary_skin.value == 'Froid/skin.xml':
		if config.plugins.FroidSetup.autoUp.value==True:
			if config.plugins.FroidSetup.autoUpSel.value == "All":
				upCheck()
				Timer = eTimer()
				Timer.callback.append(upCheck)
				Timer.start(1000*21600, False) #6h=21600sn
except:
	pass

def main(session, **kwargs):
	reload(FroidSetup)
	reload(configs)
	try:
		session.open(FroidSetup.FroidSetup)
	except:
		import traceback
		traceback.print_exc()

def Plugins(**kwargs):
	return [PluginDescriptor(name="FroidSetup", description="FroidSetup plugin for Froid skin...", where = PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)]

