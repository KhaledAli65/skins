# by digiteng...10-2019
#  <widget source="session.CurrentService" render="Label" position="50,545" size="930,40" font="Regular; 32" halign="left" transparent="1" zPosition="2" backgroundColor="back_color" valign="center">
#   	<convert type="FroidAV">AV</convert>
# </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import iServiceInformation, iPlayableService

video_codecs = ('MPEG2', 'AVC', 'H263', 'VC1', 'MPEG4-VC', 'VC1-SM', 'MPEG1', 'HEVC', 'VP8', 'VP9', 'XVID', 'N/A 11', 'N/A 12', 'DIVX 3.11', 'DIVX 4', 'DIVX 5', 'AVS', 'N/A 17', 'VP6', 'N/A 19', 'N/A 20', 'SPARK')

class FroidAV(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		service = self.source.service
		if service is None:
			return ""
		info = service and service.info()
		if not info:
			return ""

		if self.type == "Ref":
			return "Ref : " + info.getInfoString(iServiceInformation.sServiceref)

		if self.type == "AV":
			audio = service.audioTracks()
			v = (video_codecs[info.getInfo(iServiceInformation.sVideoType)])
			a = (str(audio.getTrackInfo(audio.getCurrentTrack()).getDescription()))
			return "Video/Audio : %s / %s" % (v, a)

	text = property(getText)
