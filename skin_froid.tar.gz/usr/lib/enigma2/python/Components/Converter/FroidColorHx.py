# by digiteng...07-2019
# <widget backgroundColor="back_color" source="Title" render="Label" font="Console; 32" position="1185,920" size="720,42" zPosition="2" transparent="1" halign="center" borderWidth="1" borderColor="black">
#  	<convert type="FroidColorHx" />
#  </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.config import config
from Poll import Poll

class FroidColorHx(Poll, Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)

		self.type = str(type)

		self.poll_interval = 1000
		self.poll_enabled = True

	@cached
	def text(self):
		if config.plugins.FroidSetup.Colored.value == "BACKGROUND":
			r = int(config.plugins.FroidSetup.colorR.value)
			g = int(config.plugins.FroidSetup.colorG.value)
			b = int(config.plugins.FroidSetup.colorB.value)
			rgb = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb
		if config.plugins.FroidSetup.Colored.value == "TITLE BACKGROUND":
			r = int(config.plugins.FroidSetup.colorR2.value)
			g = int(config.plugins.FroidSetup.colorG2.value)
			b = int(config.plugins.FroidSetup.colorB2.value)
			rgb2 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb2
		if config.plugins.FroidSetup.Colored.value == "TITLE FONT":
			r = int(config.plugins.FroidSetup.colorR2a.value)
			g = int(config.plugins.FroidSetup.colorG2a.value)
			b = int(config.plugins.FroidSetup.colorB2a.value)
			rgb2a = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb2a
		if config.plugins.FroidSetup.Colored.value == "TITLE LINE":
			r = int(config.plugins.FroidSetup.colorR2b.value)
			g = int(config.plugins.FroidSetup.colorG2b.value)
			b = int(config.plugins.FroidSetup.colorB2b.value)
			rgb2b = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb2b
		if config.plugins.FroidSetup.Colored.value == "OTHER LINE":
			r = int(config.plugins.FroidSetup.colorR3.value)
			g = int(config.plugins.FroidSetup.colorG3.value)
			b = int(config.plugins.FroidSetup.colorB3.value)
			rgb3 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb3
		if config.plugins.FroidSetup.Colored.value == "SELECT BAR":
			r = int(config.plugins.FroidSetup.colorR4.value)
			g = int(config.plugins.FroidSetup.colorG4.value)
			b = int(config.plugins.FroidSetup.colorB4.value)
			rgb4 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb4
		if config.plugins.FroidSetup.Colored.value == "PROGRESS":
			r = int(config.plugins.FroidSetup.colorR5.value)
			g = int(config.plugins.FroidSetup.colorG5.value)
			b = int(config.plugins.FroidSetup.colorB5.value)
			rgb5 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb5
		if config.plugins.FroidSetup.Colored.value == "PROGRESS SEL":
			r = int(config.plugins.FroidSetup.colorR5a.value)
			g = int(config.plugins.FroidSetup.colorG5a.value)
			b = int(config.plugins.FroidSetup.colorB5a.value)
			rgb5a = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb5a
		if config.plugins.FroidSetup.Colored.value == "SCROLLBAR":
			r = int(config.plugins.FroidSetup.colorR6.value)
			g = int(config.plugins.FroidSetup.colorG6.value)
			b = int(config.plugins.FroidSetup.colorB6.value)
			rgb6 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb6
		if config.plugins.FroidSetup.Colored.value == "FONT":
			r = int(config.plugins.FroidSetup.colorR7.value)
			g = int(config.plugins.FroidSetup.colorG7.value)
			b = int(config.plugins.FroidSetup.colorB7.value)
			rgb7 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb7
		if config.plugins.FroidSetup.Colored.value == "FONT SELECT":
			r = int(config.plugins.FroidSetup.colorR8.value)
			g = int(config.plugins.FroidSetup.colorG8.value)
			b = int(config.plugins.FroidSetup.colorB8.value)
			rgb8 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb8
		if config.plugins.FroidSetup.Colored.value == "RGYB BACKGROUND":
			r = int(config.plugins.FroidSetup.colorR9.value)
			g = int(config.plugins.FroidSetup.colorG9.value)
			b = int(config.plugins.FroidSetup.colorB9.value)
			rgb9 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb9
		if config.plugins.FroidSetup.Colored.value == "CLOCK":
			r = int(config.plugins.FroidSetup.colorR10.value)
			g = int(config.plugins.FroidSetup.colorG10.value)
			b = int(config.plugins.FroidSetup.colorB10.value)
			rgb10 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb10
		if config.plugins.FroidSetup.Colored.value == "SERVICE DESCRIPTION":
			r = int(config.plugins.FroidSetup.colorR12.value)
			g = int(config.plugins.FroidSetup.colorG12.value)
			b = int(config.plugins.FroidSetup.colorB12.value)
			rgb12 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb12
		if config.plugins.FroidSetup.Colored.value == "SERVICE DESCRIPTION SEL":
			r = int(config.plugins.FroidSetup.colorR12a.value)
			g = int(config.plugins.FroidSetup.colorG12a.value)
			b = int(config.plugins.FroidSetup.colorB12a.value)
			rgb12a = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb12a
		if config.plugins.FroidSetup.Colored.value == "BUTTON COLOR":
			r = int(config.plugins.FroidSetup.colorR13.value)
			g = int(config.plugins.FroidSetup.colorG13.value)
			b = int(config.plugins.FroidSetup.colorB13.value)
			rgb13 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb13
		if config.plugins.FroidSetup.Colored.value == "INFOBAR INFO":
			r = int(config.plugins.FroidSetup.colorR14.value)
			g = int(config.plugins.FroidSetup.colorG14.value)
			b = int(config.plugins.FroidSetup.colorB14.value)
			rgb14 = '{:02x}{:02x}{:02x}'.format(r, g, b)
			return "#" + rgb14

	text = property(text)
	
	def changed(self, what):
		if what[0] is self.CHANGED_SPECIFIC:
			Converter.changed(self, what)
		elif what[0] is self.CHANGED_POLL:
			self.downstream_elements.changed(what)
