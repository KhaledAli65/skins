# by digiteng...10.2020
# <widget source="session.Event_Now" render="Label" font="Console; 20" position="520,120" size="100,25" zPosition="9" backgroundColor="background" transparent="1">
  # <convert type="Evnttm">duration</convert>
# </widget>

from Converter import Converter
from time import time
from Poll import Poll
from Components.Element import cached

class FroidEventTimeInfo(Poll, Converter, object):
	
	def __init__(self, type):
		Poll.__init__(self)
		Converter.__init__(self, type)
		self.type = type
		
	@cached
	def getText(self):
		self.poll_interval = 30000
		self.poll_enabled = True
		event = self.source.event
		if event is None:
			return
		else:
			st = event.getBeginTime()
			duration = event.getDuration()
			et = st + duration
			now = int(time())
			remaining = et - now
			progressing = now - st
			progress = int(progressing * 100 / duration)
			if self.type == "progress":
				return "{}".format(str(progress))
			elif self.type == "duration":
				return "{}min".format(str(duration/60))
			elif self.type == "remaining":
				return "{}min".format(str(remaining/60))
			elif self.type == "progressing":
				return "{}min".format(gz/60)
			elif self.type == "remaining/duration":
				return "+{}/{}min".format(remaining/60, duration/60)
			elif self.type == "progressing/duration":
				return "-{}/{}min".format(progressing/60, duration/60)

	text = property(getText)
	