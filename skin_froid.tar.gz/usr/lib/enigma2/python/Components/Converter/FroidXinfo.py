# -*- coding: utf-8 -*-
# by digiteng...12.2020
# <widget source="session.CurrentService" render="Label" position="10,1025" size="1381,40" zPosition="0" font="Console; 30" transparent="1" foregroundColor="font_color" backgroundColor="title_back">
# 	<convert type="Xinfo">ecm-info</convert>
# </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
import os

class FroidXinfo(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type
		
	@cached
	def getText(self):
		ecm = ""
		mem = ""
		if self.type == "ecm-info":
			service = self.source.service
			if service:
				frontendInfo = service.frontendInfo()
				if frontendInfo:
					try:
						ecmpath = "/tmp/ecm{}.info".format(frontendInfo.getAll(False).get("tuner_number"))
						with open(ecmpath, "r") as f:
							ecm = f.readlines()
					except:
						if os.path.exists("/tmp/ecm.info"):
							with open("/tmp/ecm.info", "r") as f:
								ecm = f.readlines()
					ecmlst = []
					for i in ecm:
						ecm = i.split(":")
						if ecm[0]== "caid":
							ecmlst.append("Caid:{}".format(ecm[1].replace("0x","").strip()))
						if ecm[0]== "reader":
							ecmlst.append("Reader:{}".format(ecm[1].replace("0x","").strip())) 
						if ecm[0]== "protocol":
							ecmlst.append("Protocol:{}".format(ecm[1].replace("0x","").strip()))
						if ecm[0]== "hops":
							ecmlst.append("Hops:{}".format(ecm[1].replace("0x","").strip()))
						if ecm[0]== "ecm time":
							ecmlst.append("EcmTime:{}".format(ecm[1].replace("0x","").strip()))
					sep_color = "\\c0000????" + ", "
					sep_color += "\\c00??????"
					return sep_color.join(ecmlst)
		
		if self.type == "ram-info":
			if os.path.exists("/proc/meminfo"):
				with open("/proc/meminfo", "r") as f:
					mem = f.readlines()
				memlst = []
				for i in mem:
					mem = i.split()
					if mem[0] == "MemFree:":
						memlst.append(str(int(mem[1]) / 1000))
					if mem[0] == "MemTotal:":
						memlst.append(str(int(mem[1]) / 1000))
				rm = "RAM : {} MB".format("/".join(memlst))
				return rm
		
		if self.type == "flash-info":
			st = os.statvfs("/")
			sz = (st.f_bsize * st.f_blocks) / (1024.0 ** 3)
			szfree = (st.f_bsize * st.f_bavail) / (1024.0 ** 3)

			return "FLASH : %.1f/%.1f GB"%(sz, szfree)
		
		if self.type == "disk-info":
			if os.path.ismount("/media/hdd"):
				path = "/media/hdd"
			elif os.path.ismount("/media/usb"):
				path = "/media/usb"			
			st = os.statvfs(path)
			sz = (st.f_bsize * st.f_blocks) / (1024.0 ** 3)
			szfree= (st.f_bsize * st.f_bavail) / (1024.0 ** 3)
			return "DISK : %.1f/%.1f GB"%(sz, szfree)

		if self.type == "full":
			ecmlst = []
			service = self.source.service
			if service:
				frontendInfo = service.frontendInfo()
				if frontendInfo:
					try:
						ecmpath = "/tmp/ecm{}.info".format(frontendInfo.getAll(False).get("tuner_number"))
						with open(ecmpath, "r") as f:
							ecm = f.readlines()
					except:
						if os.path.exists("/tmp/ecm.info"):
							with open("/tmp/ecm.info", "r") as f:
								ecm = f.readlines()
					
					for i in ecm:
						ecm = i.split(":")
						if ecm[0]== "caid":
							ecmlst.append("Caid:{}".format(ecm[1].replace("0x","").strip()))
						if ecm[0]== "reader":
							ecmlst.append("Reader:{}".format(ecm[1].replace("0x","").strip())) 
						if ecm[0]== "protocol":
							ecmlst.append("Protocol:{}".format(ecm[1].replace("0x","").strip()))
						if ecm[0]== "hops":
							ecmlst.append("Hops:{}".format(ecm[1].replace("0x","").strip()))
						if ecm[0]== "ecm time":
							ecmlst.append("EcmTime:{}".format(ecm[1].replace("0x","").strip()))
					
			if os.path.exists("/proc/meminfo"):
				with open("/proc/meminfo", "r") as f:
					mem = f.readlines()
				memlst = []
				for i in mem:
					mem = i.split()
					if mem[0] == "MemFree:":
						memlst.append(str(int(mem[1]) / 1000))
					if mem[0] == "MemTotal:":
						memlst.append(str(int(mem[1]) / 1000))
				rm = "RAM : {} MB".format("/".join(memlst))
				ecmlst.append(rm)

			st = os.statvfs("/")
			sz = (st.f_bsize * st.f_blocks) / (1024.0 ** 3)
			szfree = (st.f_bsize * st.f_bavail) / (1024.0 ** 3)
			flsh_sz = "FLASH : %.1f/%.1f GB"%(sz, szfree)
			ecmlst.append(str(flsh_sz))

			if os.path.ismount("/media/hdd"):
				path = "/media/hdd"
			elif os.path.ismount("/media/usb"):
				path = "/media/usb"			
			st = os.statvfs(path)
			sz = (st.f_bsize * st.f_blocks) / (1024.0 ** 3)
			szfree= (st.f_bsize * st.f_bavail) / (1024.0 ** 3)
			dsk_sz = "DISK : %.1f/%.1f GB"%(sz, szfree)
			ecmlst.append(str(dsk_sz))

			sep_color = "\\c0000????" + " | "
			sep_color += "\\c00??????"
			return sep_color.join(ecmlst)			

		
	text = property(getText)
	