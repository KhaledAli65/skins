# -*- coding: utf-8 -*-
#
# j00zek 2018/2019/2020
# eLabel is simple to use but not translated
# this converter is to use instead and have texts localized
#
#      <!-- zamiast elabel - widget source="session.CurrentService" render="Label"-->
"""
    <widget source="session.CurrentService" render="Label" backgroundColor="black" font="Roboto_HD; 26" foregroundColor="light_yellow" position="65,210" size="210,32" transparent="1">
      <convert type="FhromaTranslator">Box Type:</convert>
    </widget>
"""

from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.FhromaSkinTranslated import translate

class FhromaTranslator(Converter, object):
    def __init__(self, LabelText):
        Converter.__init__(self, LabelText)
        self.translatedLabel  = translate(LabelText)

    @cached
    def getText(self):
        return self.translatedLabel
        
    text = property(getText)
