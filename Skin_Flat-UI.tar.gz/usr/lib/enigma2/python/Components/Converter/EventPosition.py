from Converter import Converter
from Poll import Poll
from Components.Element import cached
from time import time

class EventPosition(Poll, Converter, object):

    def __init__(self, type):
        Poll.__init__(self)
        Converter.__init__(self, type)
        self.poll_interval = 30000
        self.poll_enabled = True

    @cached
    def getPosition(self):
        event = self.source.event
        if event is None:
            return
        now = int(time())
        start_time = event.getBeginTime()
        duration = event.getDuration()
        if start_time <= now <= start_time + duration and duration > 0:
            return now - start_time
        else:
            return 0

    @cached
    def getLength(self):
        event = self.source.event
        if event is None:
            return
        return event.getDuration()

    @cached
    def getCutlist(self):
        return []

    position = property(getPosition)
    length = property(getLength)
    cutlist = property(getCutlist)

    def changed(self, what):
        if what[0] != self.CHANGED_CLEAR:
            self.downstream_elements.changed(what)
            if len(self.downstream_elements):
                if not self.source.event and self.downstream_elements[0].visible:
                    self.downstream_elements[0].visible = False
                elif self.source.event and not self.downstream_elements[0].visible:
                    self.downstream_elements[0].visible = True
