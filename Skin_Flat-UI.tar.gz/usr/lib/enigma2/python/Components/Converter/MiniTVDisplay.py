from Components.Converter.Converter import Converter
from enigma import eServiceReference, eServiceCenter, getBestPlayableServiceReference, iServiceInformation

class MiniTVDisplay(Converter, object):

    def __init__(self, type):
        Converter.__init__(self, type)
        self.pipservice = None
        self.shown = False
        try:
            from Plugins.SystemPlugins.PiPServiceRelation.plugin import getRelationDict
            self.pipServiceRelation = getRelationDict()
        except ImportError:
            self.pipServiceRelation = None

        return

    def setPiPService(self):
        if self.shown:
            currentRunningService = self.source.getCurrentRunningService()
            service = self.source.getCurrentSelectedService()
            service_center = eServiceCenter.getInstance()
            info = service_center.info(service)
            if info and info.isPlayable(service, currentRunningService):
                if service and service.flags & eServiceReference.isGroup:
                    ref = getBestPlayableServiceReference(service, eServiceReference())
                else:
                    ref = service
                if ref and not ref.flags & (eServiceReference.isMarker | eServiceReference.isDirectory):
                    if self.pipServiceRelation is not None:
                        n_service = self.pipServiceRelation.get(ref.toString(), None)
                        if n_service is not None:
                            self.pipservice = eServiceCenter.getInstance().play(eServiceReference(n_service))
                        else:
                            self.pipservice = eServiceCenter.getInstance().play(ref)
                    else:
                        self.pipservice = eServiceCenter.getInstance().play(ref)
                    if self.pipservice and not self.pipservice.setTarget(1):
                        self.pipservice.start()
                        return True
        self.pipservice = None
        return False

    def closePiPService(self):
        if self.pipservice:
            self.pipservice = None
        return