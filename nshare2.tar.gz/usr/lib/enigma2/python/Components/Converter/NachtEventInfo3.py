# -*- coding: utf-8 -*-
# by digiteng...09.2020
 # <widget source="session.Event_Now" render="Label" position="50,545" size="930,40" font="Regular; 32" halign="left" transparent="1" zPosition="2" backgroundColor="back_color" valign="center">
	# <convert type="EventInfo3">infos</convert>
# </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import iServiceInformation, iPlayableService

class NachtEventInfo3(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type
		
	def getServiceInfoString(self, info, what, convert = lambda x: "%d" % x):
		v = info.getInfo(what)
		if v == -1:
			return "N/A"
		if v == -2:
			return info.getInfoString(what)
		return convert(v)
		
	@cached
	def getText(self):
		service = self.source.service
		if service is None:
			return ""
		info = service and service.info()
		if not info:
			return ""
		if self.type == "texts":
			yres = self.getServiceInfoString(info, iServiceInformation.sVideoHeight)
			frame = self.getServiceInfoString(info, iServiceInformation.sFrameRate, lambda x: '%d fps' % ((x + 500) / 1000))
			# progressive = self.getServiceInfoString(info, iServiceInformation.sProgressive)
			gamma = ('SDR', 'HDR', 'HDR10', 'HLG', '')[info.getInfo(iServiceInformation.sGamma)]
			inf = []
			try:
				audio = service.audioTracks()
				if audio:
					n = audio.getNumberOfTracks()
					idx = 0
					while idx < n:
						i = audio.getTrackInfo(idx)
						description = i.getDescription()
						if description in ('AC3', 'AC3+', 'DTS', 'DTS-HD', 'AC-3'):
							inf.append("DOLBY")
							break
						idx += 1
			except:
				pass
			if gamma != "":
				inf.append(gamma)
			if int(yres) < 720:
				inf.append("SD")
			elif int(yres) >= 720 and int(yres) < 1080 :
				inf.append("HD")
			elif int(yres) >= 1080 and int(yres) < 2160:
				inf.append("FHD")
			elif int(yres) >= 2160:
				inf.append("4K")
			if info.getInfo(iServiceInformation.sIsCrypted) == 1:
				inf.append("$")
			else:
				inf.append("FTA")
			if info.getInfoString(iServiceInformation.sHBBTVUrl) != "":
				hbb = '\\c00??2200' + "H" + '\\c0000??00' + "b" + '\\c00????00' + "b" + '\\c0000????' + "TV"
				inf.append(hbb)
			subservices = service.subServices()
			if subservices and subservices.getNumberOfSubservices() > 0:
				inf.append("SUB")
			subtitle = service and service.subtitle()
			subtitlelist = subtitle and subtitle.getSubtitleList()
			if subtitlelist:
				if len(subtitlelist) > 0:
					inf.append("SUBT")
			audio = service.audioTracks()
			if bool(audio and audio.getNumberOfTracks() > 1):
				inf.append("A")
			if service.streamed() is not None:
				inf.append("Stream")
			tpid = info.getInfo(iServiceInformation.sTXTPID)
			if tpid != -1:
				inf.append("TxT")
			sep_color = '\\c0000????' + " | "
			sep_color += '\\c00??????'
			return sep_color.join(inf)
	text = property(getText)
	