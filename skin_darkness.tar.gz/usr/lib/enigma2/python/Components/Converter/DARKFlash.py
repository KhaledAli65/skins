# by digiteng...11-2019
#  <widget source="global.CurrentTime" render="Label" position="50,243" size="930,300" font="Regular; 32" halign="left" transparent="1" zPosition="2" backgroundColor="back_color" valign="top">
#    <convert type="DARKFlash" />
#  </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
import os
from os import path, popen

class DARKFlash(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def getText(self):
		# flash
		ffr = popen("df -m").readlines()
		for i in ffr:
			ff = i.split()
			if ff[5] == '/':
				ftotal = ff[1]
				ffree = ff[3]
				flash = "Flash : " + ffree + " / " + ftotal + " MB (free/total)"
			if ff[5] == '/media/hdd':
				ht = ff[1]
				hf = ff[3]
				hdd = "HDD : " + hf + " / " + ht + " MB (free/total)"

		return flash

	text = property(getText)
