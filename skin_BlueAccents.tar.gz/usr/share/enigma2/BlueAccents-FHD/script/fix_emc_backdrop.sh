#!/bin/bash
rm /usr/share/enigma2/skin_default/picon_default.png
cp /usr/share/enigma2/BlueAccents-FHD/picon_default.png /usr/share/enigma2/skin_default/picon_default.png