# -*- coding: utf-8 -*-
# by digiteng...06.2020, 12.2020
# file for skin FullHDLine by sunriser 07.2021

from Components.Renderer.Renderer import Renderer
from enigma import eLabel, ePixmap, eTimer, loadPNG
import re, os, sys
import json

if os.path.isdir("/media/hdd"):
	pathLoc = "/media/hdd/infos/"
else:
	pathLoc = "/tmp/infos/"

file_png = "/usr/share/enigma2/FullHDLine/icons/starsbar_empty.png"

REGEX = re.compile(
		r'([\(\[]).*?([\)\]])|'
		r'(: odc.\d+)|'
		r'(\d+: odc.\d+)|'
		r'(\d+ odc.\d+)|(:)|'
		r'/.*|'
		r'\|\s[0-9]+\+|'
		r'[0-9]+\+|'
		r'\s\d{4}\Z|'
		r'([\(\[\|].*?[\)\]\|])|'
		r'(\"|\"\.|\"\,|\.)\s.+|'
		r'\"|\.|'
		r'Премьера\.\s|'
		r'(х|Х|м|М|т|Т|д|Д)/ф\s|'
		r'(х|Х|м|М|т|Т|д|Д)/с\s|'
		r'\s(с|С)(езон|ерия|-н|-я)\s.+|'
		r'\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
		r'\.\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
		r'\s(ч|ч\.|с\.|с)\s\d{1,3}.+|'
		r'\d{1,3}(-я|-й|\sс-н).+|', re.DOTALL)

class fhdlLocalStarsbg(Renderer):
	__module__ = __name__

	def __init__(self):
		Renderer.__init__(self)

	GUI_WIDGET = ePixmap

	def changed(self, what):
		try:
			if not self.instance:
				return
			if what[0] == self.CHANGED_CLEAR:
				self.instance.hide()
			if what[0] != self.CHANGED_CLEAR:
				self.delay()
		except:
			pass

	def showLocalStarsbg(self):
		self.event = self.source.event
		if not self.event:
			return
		try:
			eventNm = REGEX.sub('', self.event.getEventName()).strip().replace('ё','е')
			infos_file = "{}{}.json".format(pathLoc, eventNm)
			if infos_file:
				with open(infos_file) as f:
					rating = json.load(f)["imdbRating"]
			if rating == "N/A" or rating == "" :
				rtng = None
			else:
				rtng = rating
			if rtng:
				self.instance.setPixmap(loadPNG(file_png))
				self.instance.show()
			else:
				self.instance.hide()
		except:
			self.instance.hide()

	def delay(self):
		self.timer = eTimer()
		self.timer.callback.append(self.showLocalStarsbg)
		self.timer.start(300, True)
