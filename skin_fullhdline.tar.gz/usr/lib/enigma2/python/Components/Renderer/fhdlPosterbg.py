# -*- coding: utf-8 -*-
# by digiteng...06.2020, 12.2020
# file for skin FullHDLine by sunriser 07.2021

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, eTimer, loadPNG
from Components.Pixmap import Pixmap

import re
import os

if os.path.isdir("/media/hdd"):
	path_folder = "/media/hdd/poster/"
else:
	path_folder = "/tmp/poster/"

pstrBG = '/usr/share/enigma2/FullHDLine/icons/posterbg.png'

REGEX = re.compile(
		r'([\(\[]).*?([\)\]])|'
		r'(: odc.\d+)|'
		r'(\d+: odc.\d+)|'
		r'(\d+ odc.\d+)|(:)|'
		r'/.*|'
		r'\|\s[0-9]+\+|'
		r'[0-9]+\+|'
		r'\s\d{4}\Z|'
		r'([\(\[\|].*?[\)\]\|])|'
		r'(\"|\"\.|\"\,|\.)\s.+|'
		r'\"|\.|'
		r'Премьера\.\s|'
		r'(х|Х|м|М|т|Т|д|Д)/ф\s|'
		r'(х|Х|м|М|т|Т|д|Д)/с\s|'
		r'\s(с|С)(езон|ерия|-н|-я)\s.+|'
		r'\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
		r'\.\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
		r'\s(ч|ч\.|с\.|с)\s\d{1,3}.+|'
		r'\d{1,3}(-я|-й|\sс-н).+|', re.DOTALL)

class fhdlPosterbg(Renderer):
	def __init__(self):
		Renderer.__init__(self)

	GUI_WIDGET = ePixmap

	def changed(self, what):
		try:
			if not self.instance:
				return
			if what[0] == self.CHANGED_CLEAR:
				self.instance.hide()
			if what[0] != self.CHANGED_CLEAR:
				self.delay()
		except:
			pass

	def showPosterbg(self):
		self.instance.hide()
		self.event = self.source.event
		if self.event is None:
			self.instance.hide()
			return
		if self.event:
			eventNm = REGEX.sub('', self.event.getEventName()).strip().replace('ё','е')
			pstrNm = "{}{}.jpg".format(path_folder, eventNm)
			if not os.path.exists(pstrNm):
				self.instance.hide()
			else:
				self.instance.setPixmap(loadPNG(pstrBG))
				self.instance.show()
		else:
			self.instance.hide()

	def delay(self):
		self.timer = eTimer()
		self.timer.callback.append(self.showPosterbg)
		self.timer.start(50, True)
